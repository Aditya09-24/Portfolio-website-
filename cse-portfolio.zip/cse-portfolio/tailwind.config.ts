import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // Deep charcoal scale used for backgrounds and surfaces
        ink: {
          950: "#0a0b0f",
          900: "#0f1117",
          800: "#161922",
          700: "#1e222d",
          600: "#2a2f3d",
        },
        // Electric blue / indigo accents
        accent: {
          300: "#9db4ff",
          400: "#7b93ff",
          500: "#5b6cff",
          600: "#4a4ff0",
          glow: "#3b82f6",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      boxShadow: {
        glow: "0 0 30px -5px rgba(91, 108, 255, 0.55)",
        "glow-sm": "0 0 18px -4px rgba(91, 108, 255, 0.5)",
      },
      keyframes: {
        "gradient-x": {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
      },
      animation: {
        "gradient-x": "gradient-x 6s ease infinite",
      },
    },
  },
  plugins: [],
};

export default config;
