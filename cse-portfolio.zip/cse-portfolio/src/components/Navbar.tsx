"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { navLinks, site } from "@/data/site";
import { useMotionPreference } from "@/context/MotionContext";
import { CloseIcon, DownloadIcon, MenuIcon, PauseIcon, SparkIcon } from "./Icons";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const { reduced, toggle } = useMotionPreference();

  // Add a stronger glass look once the user scrolls
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Highlight the link of the section currently in view
  useEffect(() => {
    const ids = navLinks.map((l) => l.href.slice(1));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => e.isIntersecting && setActive(e.target.id));
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-6">
      <nav
        aria-label="Primary"
        className={`mx-auto flex max-w-6xl items-center justify-between rounded-2xl px-4 py-3 transition-all duration-300 sm:px-6 ${
          scrolled ? "glass bg-ink-900/60 shadow-lg shadow-black/30" : "border border-transparent"
        }`}
      >
        <a href="#top" className="font-mono text-sm font-semibold tracking-tight text-white">
          <span className="text-accent-400">&lt;</span>
          {site.name.split(" ")[0]}
          <span className="text-accent-400"> /&gt;</span>
        </a>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 md:flex">
          {navLinks.map((l) => {
            const isActive = active === l.href.slice(1);
            return (
              <li key={l.href}>
                <a
                  href={l.href}
                  className={`rounded-full px-4 py-2 text-sm transition-colors ${
                    isActive ? "bg-white/10 text-white" : "text-slate-400 hover:text-white"
                  }`}
                >
                  {l.label}
                </a>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-2">
          {/* Accessibility: pause 3D + animations */}
          <button
            type="button"
            onClick={toggle}
            aria-pressed={reduced}
            aria-label={reduced ? "Enable animations" : "Reduce motion"}
            title={reduced ? "Animations off – click to enable" : "Reduce motion"}
            className="rounded-full border border-white/10 bg-white/5 p-2 text-slate-300 transition hover:border-accent-400/60 hover:text-white"
          >
            {reduced ? <SparkIcon width={18} height={18} /> : <PauseIcon width={18} height={18} />}
          </button>

          <a
            href={site.resume}
            download
            className="btn-primary hidden !px-4 !py-2 sm:inline-flex"
          >
            <DownloadIcon width={16} height={16} />
            Resume
          </a>

          <button
            type="button"
            className="rounded-full border border-white/10 bg-white/5 p-2 text-white md:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label="Toggle menu"
          >
            {open ? <CloseIcon width={18} height={18} /> : <MenuIcon width={18} height={18} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="glass mx-auto mt-2 max-w-6xl rounded-2xl bg-ink-900/80 p-3 md:hidden"
          >
            <ul className="flex flex-col">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="block rounded-xl px-4 py-3 text-slate-200 hover:bg-white/10"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li className="mt-2">
                <a href={site.resume} download className="btn-primary w-full">
                  <DownloadIcon width={16} height={16} />
                  Download Resume
                </a>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
