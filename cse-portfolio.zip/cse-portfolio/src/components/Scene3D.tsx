"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

const PARTICLE_COUNT = 900;

/**
 * A cloud of softly glowing points that drifts slowly and leans
 * toward the pointer. Uses a single <points> draw call so it stays cheap.
 */
function Particles({ animate }: { animate: boolean }) {
  const group = useRef<THREE.Group>(null);
  const points = useRef<THREE.Points>(null);

  // Positions are generated once. Points are spread in a sphere shell.
  const positions = useMemo(() => {
    const arr = new Float32Array(PARTICLE_COUNT * 3);
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const r = 3 + Math.random() * 5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      arr[i * 3 + 2] = r * Math.cos(phi);
    }
    return arr;
  }, []);

  useFrame((state, delta) => {
    if (!animate || !group.current || !points.current) return;
    // Constant slow rotation
    points.current.rotation.y += delta * 0.03;
    points.current.rotation.x += delta * 0.012;
    // Ease the whole group toward the pointer (pointer is in -1..1 range)
    const { x, y } = state.pointer;
    group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, x * 0.25, 0.04);
    group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -y * 0.2, 0.04);
  });

  return (
    <group ref={group}>
      <points ref={points}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        </bufferGeometry>
        <pointsMaterial
          color="#7b93ff"
          size={0.035}
          sizeAttenuation
          transparent
          opacity={0.85}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
    </group>
  );
}

/** A wireframe icosahedron that gently floats in the centre as a focal point. */
function FloatingMesh({ animate }: { animate: boolean }) {
  const mesh = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (!animate || !mesh.current) return;
    mesh.current.rotation.x += delta * 0.12;
    mesh.current.rotation.y += delta * 0.18;
    mesh.current.position.y = Math.sin(state.clock.elapsedTime * 0.6) * 0.25;
  });

  return (
    <mesh ref={mesh} position={[2.4, 0, -1]}>
      <icosahedronGeometry args={[1.5, 1]} />
      <meshBasicMaterial color="#4a4ff0" wireframe transparent opacity={0.28} />
    </mesh>
  );
}

/**
 * Full-screen, non-interactive 3D layer pinned behind the page.
 * - `animate=false` renders a single still frame (frameloop="demand"),
 *   which uses practically no GPU – this powers the reduce-motion mode.
 * - DPR is capped at 1.5 and antialiasing is off for mobile performance.
 */
export default function Scene3D({ animate }: { animate: boolean }) {
  return (
    <Canvas
      camera={{ position: [0, 0, 6], fov: 60 }}
      dpr={[1, 1.5]}
      gl={{ antialias: false, alpha: true, powerPreference: "low-power" }}
      frameloop={animate ? "always" : "demand"}
      // Events are attached to the window so the canvas can stay pointer-events:none
      eventSource={typeof document !== "undefined" ? document.body : undefined}
      eventPrefix="client"
    >
      <Particles animate={animate} />
      <FloatingMesh animate={animate} />
    </Canvas>
  );
}
