import { site } from "@/data/site";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-8 text-center text-sm text-slate-500">
      <p>
        © {new Date().getFullYear()} {site.name}. Built with Next.js, Tailwind, Framer Motion &amp;
        React Three Fiber.
      </p>
    </footer>
  );
}
