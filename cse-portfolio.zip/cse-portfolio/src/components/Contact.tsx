"use client";

import { useState, type FormEvent } from "react";
import { site } from "@/data/site";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { GithubIcon, LinkedinIcon, MailIcon } from "./Icons";

type Status = "idle" | "sending" | "success" | "error";

const socials = [
  { label: "GitHub", href: site.github, Icon: GithubIcon },
  { label: "LinkedIn", href: site.linkedin, Icon: LinkedinIcon },
  { label: "Email", href: `mailto:${site.email}`, Icon: MailIcon },
];

const fieldClass =
  "w-full rounded-xl border border-white/10 bg-ink-900/60 px-4 py-3 text-sm text-white placeholder:text-slate-600 transition focus:border-accent-400 focus:outline-none focus:ring-2 focus:ring-accent-500/30";

export default function Contact() {
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    setStatus("sending");
    setMessage("");

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };

      if (!res.ok || !json.ok) throw new Error(json.error || "Something went wrong.");

      setStatus("success");
      setMessage("Thanks! Your message is on its way — I'll reply soon.");
      form.reset();
    } catch (err) {
      setStatus("error");
      setMessage(
        err instanceof Error
          ? err.message
          : `Couldn't send right now. Please email me at ${site.email}.`
      );
    }
  }

  return (
    <section id="contact" className="section">
      <SectionHeading
        eyebrow="04 / Contact"
        title="Let's Connect"
        subtitle="Got feedback, an idea, or a study-group invite? My inbox is open."
      />

      <div className="grid gap-8 lg:grid-cols-5">
        {/* Form */}
        <Reveal className="lg:col-span-3">
          <form onSubmit={onSubmit} className="glass space-y-5 rounded-2xl p-6 sm:p-8" noValidate={false}>
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="name" className="mb-2 block text-sm text-slate-400">
                  Name
                </label>
                <input id="name" name="name" required maxLength={80} placeholder="Ada Lovelace" className={fieldClass} />
              </div>
              <div>
                <label htmlFor="email" className="mb-2 block text-sm text-slate-400">
                  Email
                </label>
                <input id="email" name="email" type="email" required maxLength={120} placeholder="ada@example.com" className={fieldClass} />
              </div>
            </div>

            <div>
              <label htmlFor="message" className="mb-2 block text-sm text-slate-400">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                required
                minLength={10}
                maxLength={2000}
                rows={5}
                placeholder="Hi! I'd love to chat about..."
                className={`${fieldClass} resize-none`}
              />
            </div>

            {/* Honeypot – hidden from humans, bots tend to fill it in */}
            <input
              type="text"
              name="website"
              tabIndex={-1}
              autoComplete="off"
              aria-hidden
              className="absolute -left-[9999px] h-0 w-0 opacity-0"
            />

            <div className="flex flex-wrap items-center gap-4">
              <button type="submit" disabled={status === "sending"} className="btn-primary disabled:opacity-60">
                {status === "sending" ? "Sending…" : "Send Message"}
              </button>
              <p
                role="status"
                aria-live="polite"
                className={`text-sm ${status === "success" ? "text-emerald-400" : "text-rose-400"}`}
              >
                {message}
              </p>
            </div>
          </form>
        </Reveal>

        {/* Direct links */}
        <Reveal delay={0.15} className="lg:col-span-2">
          <div className="glass h-full rounded-2xl p-6 sm:p-8">
            <h3 className="mb-6 font-mono text-xs uppercase tracking-[0.25em] text-accent-400">
              Find me online
            </h3>
            <ul className="space-y-3">
              {socials.map(({ label, href, Icon }) => (
                <li key={label}>
                  <a
                    href={href}
                    target={label === "Email" ? undefined : "_blank"}
                    rel="noopener noreferrer"
                    className="group flex items-center gap-4 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 transition hover:border-accent-400/60 hover:bg-white/[0.07]"
                  >
                    <Icon className="text-accent-400 transition group-hover:scale-110" />
                    <span className="text-slate-200">{label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
