"use client";

import { motion } from "framer-motion";
import { projects, type Project } from "@/data/site";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { ExternalIcon, GithubIcon } from "./Icons";

function ProjectCard({ project }: { project: Project }) {
  return (
    <motion.article
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
      className="glass group relative flex h-full flex-col overflow-hidden rounded-2xl transition-shadow duration-300 hover:shadow-glow"
    >
      {/* Decorative header – swap for a real screenshot with next/image later */}
      <div className="relative h-36 overflow-hidden bg-gradient-to-br from-accent-600/40 via-ink-800 to-ink-900">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:24px_24px]" />
        <span className="absolute bottom-3 left-5 font-mono text-5xl font-bold text-white/20 transition-colors group-hover:text-accent-400/50">
          {project.badge}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="text-xl font-semibold text-white">{project.title}</h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-slate-400">{project.description}</p>

        <ul className="mt-5 flex flex-wrap gap-2" aria-label="Tech stack">
          {project.stack.map((s) => (
            <li
              key={s}
              className="rounded-md bg-white/5 px-2.5 py-1 font-mono text-[11px] text-slate-300"
            >
              {s}
            </li>
          ))}
        </ul>

        <div className="mt-6 flex gap-3">
          <a
            href={project.github}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost !px-4 !py-2"
            aria-label={`${project.title} on GitHub`}
          >
            <GithubIcon width={16} height={16} />
            Code
          </a>
          <a
            href={project.demo}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary !px-4 !py-2"
            aria-label={`${project.title} live demo`}
          >
            <ExternalIcon width={16} height={16} />
            Live Demo
          </a>
        </div>
      </div>
    </motion.article>
  );
}

export default function Projects() {
  return (
    <section id="projects" className="section">
      <SectionHeading
        eyebrow="03 / Projects"
        title="Things I've Built"
        subtitle="Small projects, big lessons. Each one taught me something new about writing and shipping code."
      />

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((p, i) => (
          <Reveal key={p.title} delay={i * 0.1}>
            <ProjectCard project={p} />
          </Reveal>
        ))}
      </div>
    </section>
  );
}
