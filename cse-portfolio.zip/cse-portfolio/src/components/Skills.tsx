"use client";

import { motion } from "framer-motion";
import { skillCategories } from "@/data/site";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Skills() {
  return (
    <section id="skills" className="section">
      <SectionHeading
        eyebrow="02 / Skills"
        title="Skills & Tech Stack"
        subtitle="Honest snapshot of what I use today and what I'm working toward."
      />

      <div className="grid gap-6 md:grid-cols-3">
        {skillCategories.map((cat, i) => (
          <Reveal key={cat.title} delay={i * 0.1}>
            <motion.div
              whileHover={{ y: -6 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="glass group h-full rounded-2xl p-6 transition-shadow duration-300 hover:shadow-glow-sm"
            >
              <h3 className="text-xl font-semibold text-white">{cat.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{cat.description}</p>

              <ul className="mt-6 flex flex-wrap gap-2">
                {cat.items.map((item) => (
                  <li
                    key={item}
                    className="rounded-full border border-accent-500/30 bg-accent-500/10 px-3.5 py-1.5 font-mono text-xs text-accent-300 transition-colors group-hover:border-accent-400/60"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
