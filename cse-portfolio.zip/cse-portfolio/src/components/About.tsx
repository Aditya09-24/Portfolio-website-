import { about } from "@/data/site";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function About() {
  return (
    <section id="about" className="section">
      <SectionHeading eyebrow="01 / About" title={about.heading} />

      <div className="grid gap-10 lg:grid-cols-5">
        {/* Bio */}
        <div className="space-y-5 text-base leading-relaxed text-slate-400 sm:text-lg lg:col-span-3">
          {about.paragraphs.map((p, i) => (
            <Reveal key={i} delay={i * 0.1}>
              <p>{p}</p>
            </Reveal>
          ))}
        </div>

        {/* Focus card */}
        <Reveal delay={0.2} className="lg:col-span-2">
          <div className="glass rounded-2xl p-6">
            <h3 className="mb-4 font-mono text-xs uppercase tracking-[0.25em] text-accent-400">
              Current focus
            </h3>
            <ul className="space-y-3">
              {about.focus.map((f) => (
                <li key={f} className="flex items-start gap-3 text-slate-300">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-400 shadow-glow-sm" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>

      {/* Quick stats */}
      <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {about.stats.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.08}>
            <div className="glass rounded-2xl p-5 text-center">
              <div className="gradient-text text-3xl font-bold">{s.value}</div>
              <div className="mt-1 text-xs uppercase tracking-widest text-slate-500">{s.label}</div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
