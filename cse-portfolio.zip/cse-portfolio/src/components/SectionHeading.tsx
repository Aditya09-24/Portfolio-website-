import Reveal from "./Reveal";

interface Props {
  eyebrow: string;
  title: string;
  subtitle?: string;
}

/** Consistent heading block used at the top of every section. */
export default function SectionHeading({ eyebrow, title, subtitle }: Props) {
  return (
    <Reveal className="mb-14 max-w-2xl">
      <p className="mb-3 font-mono text-xs uppercase tracking-[0.25em] text-accent-400">
        {eyebrow}
      </p>
      <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl md:text-5xl">
        {title}
      </h2>
      {subtitle && <p className="mt-4 text-base text-slate-400 sm:text-lg">{subtitle}</p>}
    </Reveal>
  );
}
