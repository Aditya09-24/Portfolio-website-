"use client";

import { motion, type Variants } from "framer-motion";
import { site } from "@/data/site";
import { ArrowDownIcon } from "./Icons";

// Parent staggers its children for a cascading entrance
const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.15 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function Hero() {
  return (
    <section
      id="top"
      className="relative mx-auto flex min-h-screen w-full max-w-6xl flex-col justify-center px-5 pb-16 pt-32 sm:px-8"
    >
      <motion.div variants={container} initial="hidden" animate="show" className="max-w-3xl">
        <motion.p
          variants={item}
          className="glass mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 font-mono text-xs text-accent-300"
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent-400 opacity-75 motion-reduce:animate-none" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-accent-400" />
          </span>
          Open to learning &amp; collaborating
        </motion.p>

        <motion.h1
          variants={item}
          className="text-4xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl"
        >
          <span className="gradient-text">{site.name}</span>
          <span className="text-slate-500"> — </span>
          {site.title}
        </motion.h1>

        <motion.p variants={item} className="mt-6 max-w-2xl text-base text-slate-400 sm:text-lg">
          {site.tagline}
        </motion.p>

        <motion.div variants={item} className="mt-10 flex flex-wrap gap-4">
          <a href="#projects" className="btn-primary">
            View Projects
            <ArrowDownIcon width={16} height={16} />
          </a>
          <a href="#contact" className="btn-ghost">
            Get in Touch
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll hint */}
      <motion.a
        href="#about"
        aria-label="Scroll to About"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 text-slate-500 transition hover:text-white sm:block"
      >
        <ArrowDownIcon className="animate-bounce motion-reduce:animate-none" />
      </motion.a>
    </section>
  );
}
