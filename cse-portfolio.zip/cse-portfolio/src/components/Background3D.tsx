"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { useMotionPreference } from "@/context/MotionContext";

/**
 * Three.js is heavy, so it is loaded lazily in the browser only
 * (never during SSR) and never blocks the first paint.
 */
const Scene3D = dynamic(() => import("./Scene3D"), { ssr: false });

/** Quick check so we can skip WebGL entirely on unsupported devices. */
function hasWebGL(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return !!(canvas.getContext("webgl2") || canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

export default function Background3D() {
  const { reduced } = useMotionPreference();
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    setSupported(hasWebGL());
  }, []);

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink-950"
    >
      {/* Static gradient glow – always visible, also the fallback without WebGL */}
      <div className="absolute -left-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-accent-600/20 blur-[120px]" />
      <div className="absolute -bottom-40 -right-40 h-[32rem] w-[32rem] rounded-full bg-indigo-500/15 blur-[120px]" />

      {supported && (
        <div className="absolute inset-0 opacity-90">
          <Scene3D animate={!reduced} />
        </div>
      )}

      {/* Vignette keeps text readable over the particles */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(10,11,15,0.75)_100%)]" />
    </div>
  );
}
