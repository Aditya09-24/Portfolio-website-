export interface ContactPayload {
  name: string;
  email: string;
  message: string;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Server-side validation – never trust the browser.
 * Returns the cleaned payload or an error message.
 */
export function validateContact(
  input: unknown
): { ok: true; data: ContactPayload } | { ok: false; error: string } {
  if (typeof input !== "object" || input === null) {
    return { ok: false, error: "Invalid request." };
  }
  const { name, email, message } = input as Record<string, unknown>;

  if (typeof name !== "string" || name.trim().length < 1 || name.length > 80) {
    return { ok: false, error: "Please enter your name." };
  }
  if (typeof email !== "string" || !EMAIL_RE.test(email) || email.length > 120) {
    return { ok: false, error: "Please enter a valid email address." };
  }
  if (typeof message !== "string" || message.trim().length < 10 || message.length > 2000) {
    return { ok: false, error: "Message should be between 10 and 2000 characters." };
  }

  return {
    ok: true,
    data: { name: name.trim(), email: email.trim(), message: message.trim() },
  };
}

/** Escape user text before putting it into an HTML email. */
export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
