"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { MotionConfig } from "framer-motion";

interface MotionState {
  /** true when animations (3D + scroll effects) should be minimised */
  reduced: boolean;
  toggle: () => void;
}

const MotionCtx = createContext<MotionState>({ reduced: false, toggle: () => {} });

const STORAGE_KEY = "portfolio:reduce-motion";

/**
 * Single source of truth for the accessibility "reduce motion" switch.
 * - Defaults to the OS-level `prefers-reduced-motion` setting.
 * - A manual toggle in the navbar overrides it and is remembered.
 * - Also feeds Framer Motion's <MotionConfig> so every animation obeys it.
 */
export function MotionProvider({ children }: { children: ReactNode }) {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    let saved: string | null = null;
    try {
      saved = localStorage.getItem(STORAGE_KEY);
    } catch {
      /* storage may be unavailable (private mode) – ignore */
    }
    setReduced(saved !== null ? saved === "1" : mq.matches);
  }, []);

  const toggle = useCallback(() => {
    setReduced((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(STORAGE_KEY, next ? "1" : "0");
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const value = useMemo(() => ({ reduced, toggle }), [reduced, toggle]);

  return (
    <MotionCtx.Provider value={value}>
      <MotionConfig reducedMotion={reduced ? "always" : "never"}>{children}</MotionConfig>
    </MotionCtx.Provider>
  );
}

export const useMotionPreference = () => useContext(MotionCtx);
