/**
 * ✏️  EDIT THIS FILE to personalise the whole portfolio.
 * Everything visible on the site is driven from here.
 */

export const site = {
  name: "Your Name",
  title: "First-Year CSE Student & Aspiring Software Engineer",
  tagline:
    "Passionate about building things with code, exploring data structures, and learning modern web development.",
  email: "you@example.com",
  github: "https://github.com/your-username",
  linkedin: "https://www.linkedin.com/in/your-username",
  resume: "/resume.pdf", // put your PDF in /public/resume.pdf
  url: "https://your-portfolio.vercel.app",
};

export const navLinks = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

export const about = {
  heading: "My Journey",
  paragraphs: [
    "I just started my B.Tech in Computer Science Engineering, and every week feels like unlocking a new level. What began as curiosity about how apps and games work has turned into a daily habit of writing code, breaking things, and figuring out why.",
    "Right now I'm building strong fundamentals: programming in C++ and Python, practising problem-solving, and getting my hands dirty with web development. I love that a few lines of code can become something someone can actually use.",
  ],
  focus: [
    "Core programming in C++ & Python",
    "Data structures & problem solving",
    "Modern web development (HTML, CSS, JS)",
    "Git & GitHub workflows",
  ],
  stats: [
    { label: "Year", value: "1st" },
    { label: "Languages", value: "4" },
    { label: "Projects", value: "3" },
    { label: "Mindset", value: "∞" },
  ],
};

export interface SkillCategory {
  title: string;
  description: string;
  items: string[];
}

export const skillCategories: SkillCategory[] = [
  {
    title: "Languages",
    description: "What I write most often",
    items: ["C++", "Python", "JavaScript", "HTML/CSS"],
  },
  {
    title: "Tools & Tech",
    description: "How I build and ship",
    items: ["Git", "GitHub", "VS Code", "Tailwind CSS"],
  },
  {
    title: "Currently Learning",
    description: "On my roadmap this semester",
    items: ["Data Structures", "Algorithms", "React", "Next.js"],
  },
];

export interface Project {
  title: string;
  description: string;
  stack: string[];
  github: string;
  demo: string;
  /** Short visual tag shown on the card header */
  badge: string;
}

// 🔁 Replace these placeholders with your real projects and links.
export const projects: Project[] = [
  {
    title: "Interactive Calculator",
    description:
      "A responsive calculator with keyboard support, chained operations and a clean history panel. Built to practise DOM events and state handling.",
    stack: ["HTML", "CSS", "JavaScript"],
    github: "https://github.com/your-username/calculator",
    demo: "https://your-username.github.io/calculator",
    badge: "01",
  },
  {
    title: "Weather Now",
    description:
      "Search any city and see live temperature, conditions and a 5-day outlook. My first project consuming a public REST API with async/await.",
    stack: ["JavaScript", "REST API", "Tailwind CSS"],
    github: "https://github.com/your-username/weather-app",
    demo: "https://your-username.github.io/weather-app",
    badge: "02",
  },
  {
    title: "Tic-Tac-Toe CLI & Web",
    description:
      "Classic game implemented twice: a C++ terminal version to learn logic and arrays, and a web version with a simple unbeatable AI (minimax).",
    stack: ["C++", "JavaScript", "Algorithms"],
    github: "https://github.com/your-username/tic-tac-toe",
    demo: "https://your-username.github.io/tic-tac-toe",
    badge: "03",
  },
];
