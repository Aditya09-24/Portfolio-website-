# First-Year CSE Portfolio

A dark, glassmorphic portfolio built with **Next.js (App Router)**, **Tailwind CSS**, **Framer Motion** and **React Three Fiber**.

## Quick start

```bash
npm install
cp .env.example .env.local   # optional – enables the contact form
npm run dev                  # http://localhost:3000
```

## Make it yours

1. Edit **`src/data/site.ts`**: name, bio, skills, projects and social links. Everything on the page comes from this file.
2. Drop your resume at **`public/resume.pdf`** (the navbar button downloads it).
3. Replace the placeholder GitHub / demo URLs in the `projects` array.

## Contact form

`POST /api/contact` validates input on the server and sends mail through [Resend](https://resend.com) (no extra npm package).
Set `RESEND_API_KEY` and `CONTACT_TO_EMAIL` in `.env.local` (and in your hosting dashboard). Without them the form shows a friendly message pointing to your email link.

## Performance & accessibility

- Three.js is lazy-loaded client-side only; DPR is capped at 1.5, antialiasing is off, a single `<points>` draw call is used.
- The navbar **pause button** (or your OS "reduce motion" setting) stops the 3D animation (renders one still frame) and disables Framer Motion transforms. The choice is remembered.
- Falls back to a static gradient background if WebGL isn't available.

## Structure

```
src/
  app/            layout, page, globals.css, api/contact/route.ts
  components/     Navbar, Hero, About, Skills, Projects, Contact, Footer,
                  Background3D (lazy wrapper) + Scene3D (R3F scene), Reveal, Icons
  context/        MotionContext (reduce-motion state)
  data/site.ts    all editable content
  lib/validate.ts server-side form validation
```

## Deploy

Push to GitHub and import the repo on [Vercel](https://vercel.com) — zero config.
